<?php $__currentLoopData = ['success', 'warning', 'danger']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php if(session($status)): ?>
		<div class="alert alert-<?php echo e($status); ?> alert-dismissable sustom-<?php echo e($status); ?>-box">
			<strong><?php echo e(session($status)); ?></strong>
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
            </button>
		</div>
	<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\tugas8\resources\views/Layout/notif.blade.php ENDPATH**/ ?>