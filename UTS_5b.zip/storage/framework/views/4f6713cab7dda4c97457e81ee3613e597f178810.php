

<?php $__env->startSection('title', 'Beranda'); ?>


<?php $__env->startSection('content'); ?>
<!-- Page Content -->
<div class="container mt-5">

  <div class="row">
    <div class="col-lg-6 col-md-12"><h3 class="mt-4">ARTIKEL</h3></div>
    <div class="col-lg-6 col-md-12">
      <form action="<?php echo e(url('artikel/filter')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="input-group mt-4">
          <input type="text" name="judul"  value="<?php echo e($judul ?? ""); ?>" class="form-control typeahead" placeholder="Cari artikel ..." aria-label="Recipient's username" aria-describedby="button-addon2">
          <div class="input-group-append">
            <button class="btn btn-outline-secondary" id="button-addon2">Cari</button>
          </div>
        </div>
      </form>
    </div>
  </div>

  <!-- Page Features -->
  <div class="row">

<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_artikel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="col-lg-12 col-md-6 mb-4">
      <div class="card mt-5">
        <div class="card-body">
          <h4 class="card-title"><?php echo e($data_artikel->judul); ?></h4>
          <i>Post : <a href=""><p><?php echo e($data_artikel->created_at); ?></p></a></i>
          <p><?php echo e($data_artikel->isi); ?></p>
        </div>
        <div class="card-footer">
          <a href="#" class="btn btn-primary">Find Out More!</a>
        </div>
      </div>
    </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


  </div>
  <!-- /.row -->

</div>
<!-- /.container -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout/usertemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tugas8\resources\views/artikel.blade.php ENDPATH**/ ?>