

<?php if(Auth::check()): ?>
	<?php echo $__env->make('Layout.notif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo e(request()->user()->id); ?>

	<?php echo e(request()->user()->nama); ?>

	<?php echo e(request()->user()->email); ?>


<?php else: ?>

	Silahkan login

<?php endif; ?><?php /**PATH C:\xampp\htdocs\tugas8\resources\views/User/beranda.blade.php ENDPATH**/ ?>