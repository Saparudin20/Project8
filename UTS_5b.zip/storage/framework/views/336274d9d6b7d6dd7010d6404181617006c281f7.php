

<?php $__env->startSection('title', 'User || Beranda'); ?>
<?php $__env->startSection('content'); ?>
<main>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card mb-4 mt-5">
                    <div class="card-header">
                     <div class="row">
                         <div class="col-md-12"><h3 class="header-title">FORM EDIT ARTIKEL</h3></div>
                     </div>
                     <div class="row">
                         <div class="col-md-12"><?php echo $__env->make('Layout.notif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                     </div>
                    </div>
                 <div class="card-body">
                    <div class="table-responsive">
                        <form method="post" action="<?php echo e(url('artikel/edit', $artikel->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field("PUT"); ?>
                            <table class="table">
                                <tr>
                                    <td>
                                        <label>ID</label>
                                         <input type="text" name="user_id" value="<?php echo e($artikel->user_id); ?>" class="form-control" placeholder="Id ..." required="" autocomplete="off" readonly>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label>Judul</label>
                                        <input type="text" name="judul" value="<?php echo e($artikel->judul); ?>" class="form-control" placeholder="Judul ..." required="" autocomplete="off">
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label>Isi</label>
                                        <textarea rows="5" type="textarea" name="isi" placeholder="isi artikel ..." required="" autocomplete="off" id="editor"><?php echo e($artikel->isi); ?></textarea>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="right">
                                        <button class="btn btn-primary">SIMPAN</button>
                                    </td>
                                </tr>
                            </table>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout/maintemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tugas8\resources\views/Artikel/edit.blade.php ENDPATH**/ ?>