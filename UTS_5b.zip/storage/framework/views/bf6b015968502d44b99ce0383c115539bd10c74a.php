

<?php $__env->startSection('title', 'User || Beranda'); ?>
<?php $__env->startSection('content'); ?>
<main>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card mb-4 mt-5">
                    <div class="card-header">
                     <h3 class="header-title"><?php echo e($artikel->judul); ?></h3>
                 </div>
                 <div class="card-body">
                    <p>Post : <a href=""><i><?php echo e($artikel->created_at); ?></i></a></p>
                    <p><?php echo e($artikel->isi); ?></p>
                </div>
            </div>
        </div>
    </div>
</div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout/maintemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tugas8\resources\views/Artikel/detail.blade.php ENDPATH**/ ?>